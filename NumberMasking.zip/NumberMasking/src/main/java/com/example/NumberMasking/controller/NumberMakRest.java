package com.example.NumberMasking.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.NumberMasking.service.MaskNumberService;

@RestController
@RequestMapping("/api")
public class NumberMakRest {

    @Autowired
    private MaskNumberService maskNumberService;

    @PutMapping(value = "/mask/4digit", consumes = "application/json", produces = "application/json")
    String getMaskLast4Digit(@RequestBody String number){
        return maskNumberService.maskNumber(4,number);
    }

    @PutMapping(value = "/mask/2digit",consumes = "application/json",produces = "application/json")
    String getMaskLast2Digit(@RequestBody String number) {
        return maskNumberService.maskNumber(2, number);
    }
}
