package com.example.NumberMasking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NumberMaskingApplication {

	public static void main(String[] args) {
		SpringApplication.run(NumberMaskingApplication.class, args);
	}

}
