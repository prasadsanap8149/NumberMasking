package com.example.NumberMasking.service;

import org.springframework.stereotype.Service;

@Service
public class MaskNumberService {

    public String maskNumber(int digit,String number){
        if(digit==2)
            return number.replaceAll("\\d(?<!^.)(?<!^..)(?<!^...)(?<!^....)(?<!^.....)(?<!^......)(?=(?:\\D*\\d){"+digit+"})", "X");
        return number.replaceAll("\\d(?<!^.)(?<!^..)(?<!^...)(?<!^....)(?=(?:\\D*\\d){"+digit+"})", "X");
    }
}
