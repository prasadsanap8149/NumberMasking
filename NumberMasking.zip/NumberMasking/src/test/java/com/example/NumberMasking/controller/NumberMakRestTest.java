package com.example.NumberMasking.controller;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.when;

import com.example.NumberMasking.service.MaskNumberService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ContextConfiguration(classes = { NumberMakRest.class })
@ExtendWith(SpringExtension.class)
class NumberMakRestTest {
    @MockBean
    private MaskNumberService maskNumberService;

    @Autowired
    private NumberMakRest numberMakRest;


    @Test
    void testGetMaskLast2Digit() throws Exception {
        when(maskNumberService.maskNumber(anyInt(), (String) any())).thenReturn("test_response");
        MockHttpServletRequestBuilder contentTypeResult = MockMvcRequestBuilders.put("/api/mask/2digit")
                                                                                .contentType(MediaType.APPLICATION_JSON);

        ObjectMapper objectMapper = new ObjectMapper();
        MockHttpServletRequestBuilder requestBuilder = contentTypeResult
            .content(objectMapper.writeValueAsString(new String()));
        MockMvcBuilders.standaloneSetup(numberMakRest)
                       .build()
                       .perform(requestBuilder)
                       .andExpect(MockMvcResultMatchers.status().isOk())
                       .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                       .andExpect(MockMvcResultMatchers.content().string("test_response"));
    }


    @Test
    void testGetMaskLast4Digit() throws Exception {
        when(maskNumberService.maskNumber(anyInt(), (String) any())).thenReturn("test_response");
        MockHttpServletRequestBuilder contentTypeResult = MockMvcRequestBuilders.put("/api/mask/4digit")
                                                                                .contentType(MediaType.APPLICATION_JSON);

        ObjectMapper objectMapper = new ObjectMapper();
        MockHttpServletRequestBuilder requestBuilder = contentTypeResult
            .content(objectMapper.writeValueAsString(new String()));
        MockMvcBuilders.standaloneSetup(numberMakRest)
                       .build()
                       .perform(requestBuilder)
                       .andExpect(MockMvcResultMatchers.status().isOk())
                       .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                       .andExpect(MockMvcResultMatchers.content().string("test_response"));
    }
}

