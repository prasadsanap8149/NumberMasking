package com.example.NumberMasking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NumberMaskingApplicationTests {

	@Test
	void contextLoads() {
	}

}
