package com.example.NumberMasking.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = { MaskNumberService.class })
@ExtendWith(SpringExtension.class)
class MaskNumberServiceTest {
    @Autowired
    private MaskNumberService maskNumberService;


    @Test
    void testMaskNumber_4_digit() {
        assertEquals("1234XXABXXCD9012", maskNumberService.maskNumber(4, "123456AB78CD9012"));
    }

    @Test
    void testMaskNumber_2_digit() {
        assertEquals("123456XXXXXXXX56", maskNumberService.maskNumber(2, "1234567890123456"));
    }

    @Test
    void testMaskNumber_withAllAlphabet() {
        assertEquals("ABCDEFGHABCDEFGH", maskNumberService.maskNumber(4, "ABCDEFGHABCDEFGH"));
    }


}

